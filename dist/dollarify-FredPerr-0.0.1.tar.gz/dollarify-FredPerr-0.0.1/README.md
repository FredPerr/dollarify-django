# Dollarify


By default, database authentication informations are stored in the database.ini file at the root of the project.
### database.ini:
```
[postgresql]
host=localhost
database=dollarify-api
user=postgres
password=SecurePas$1
port=5432
```