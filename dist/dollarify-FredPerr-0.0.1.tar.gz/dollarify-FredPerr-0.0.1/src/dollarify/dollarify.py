def test():
    print('Hello, world')